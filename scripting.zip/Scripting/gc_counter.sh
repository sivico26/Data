#/usr/bin/bash

## General struture of a for loop:


## 	for VARIABLE in SECUENCIA
##	do
## 		STATEMENTS
## 	done

DNA=$1
GC=0

for nuc in C G; do
	temp=$(echo $DNA | grep -o $nuc | wc -l)
	let GC=$GC+$temp
done

len=$(echo $DNA | wc -c)
GC=$(echo $GC/$len | bc -l)

echo "El porcentaje de GC del fragmento dado es $GC"
