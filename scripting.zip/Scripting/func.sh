#!/usr/bin/bash

function marco {
#	MARCO=$(pwd)

	MARCO=$1
	echo $MARCO
}

function polo {
	cd $MARCO
}
