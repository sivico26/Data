#1/usr/bin/bash

## If general structure:
##
##	if CONDITION
##	then
##		STATEMENT
##	[elif CONDITION
##	then
##		STATEMENT]
##	[else
##		STATEMENT]
##	fi

## This script tells the sounds some animals make

animal=$1
raza=$2

if [[ $animal == 'perro' ]]; then

	if [[ $raza == 'salchicha' ]]; then
		echo "Guau de salchicha"
	else
		echo "Guau!"
		echo "Así sonaría un perro cualquiera"
	fi
	echo "Fin del if interno"

elif [[ $animal == 'gato' ]]; then
	echo "Miau!"
elif [[ $animal == 'pez' ]]; then
	echo 'glup, glup'
elif [[ $animal == 'pollo' ]]; then
	echo 'pio, pio'
else
	echo 'I do not know that animal'
fi
echo "Fin del if externo"
