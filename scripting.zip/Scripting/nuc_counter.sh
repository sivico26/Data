#/usr/bin/bash

## General struture of a for loop:

## 	for VARIABLE in SECUENCIA
##	do
## 		STATEMENTS
## 	done

DNA=$1

for nuc in A C G T; do
	temp=$(echo $DNA | grep -o $nuc | wc -l)
	echo "Hay $temp $nuc en el fragmento"
done
