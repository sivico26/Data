#!/usr/bin/bash

## General struture of a for loop:

## 	for VARIABLE in SECUENCIA
##	do
## 		STATEMENTS
## 	done


for number in $(seq 1 9)
do
	echo "Esta linea es la número $number"
done

echo "Esta es el fin del ciclo for"
